from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render
from django import template

#def home(request):
 #   return HttpResponse('Привет, Мир!'.encode('utf-8'), content_type="text/plain; charset=utf-8")
def home(request):
    return render(request, 'templates/static_handler.html')
def static_handler(request):
    return render(request, 'static_handler.html')
# Create your views here.
